﻿using System;
using System.Windows.Forms;
using AgileCrawlerLib.Configuration;
using Leo.Utility;
using System.Configuration;
using VMSJob;
using AgileCrawlerLib.Fieldglass;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VMSFieldglassCrawler
{
    public partial class FieldglassForm : Form
    {
        #region Variables
        private static WebBrowser browser;
        public static AgileConfiguration agileConfiguration;
        private static bool isLogin, isPostingJobs, isExpandClick, isJobListNavigated, isJobClicked = false;
        Timer exitTimer, rowIterationTimer;
        int counter, intDDLCount, intTotalJobsCount, intPageCount = 0;
        //string strhref = string.Empty;

        JobIDList jobIDList = null;
        IJobCache jobCache = new JobCache();
        #endregion
        public FieldglassForm(string[] args)
        {
            try
            {
                if (Convert.ToBoolean(ConfigurationManager.AppSettings["EnableConfigVmsId"]))
                    args = new string[] { ConfigurationManager.AppSettings["VmsId"].ToString().Trim() };

                LogManagement.LogTrace(0, "FieldglassForm()", "VmsId: " + args[0]);

                #region properties
                //agileConfiguration = new AgileConfiguration();
                //agileConfiguration.Clientname = "abbott";
                //agileConfiguration.VMSClientID = 1;
                //agileConfiguration.Username = "spfrecruiter";
                //agileConfiguration.Password = "Spectra@457";
                //agileConfiguration.URL = "https://www.fieldglass.net/";
                //agileConfiguration.JOBLIST_URL = "https://www.fieldglass.net/job_posting_list.do?sgjy=";
                //agileConfiguration.AUT_VIEWSTATE
                #endregion

                if (args.Length > 0)
                    agileConfiguration = VMSFieldglass.GetAgileConfiguration(Convert.ToInt32(args[0].Trim()));

                if (string.IsNullOrEmpty(agileConfiguration.URL) || string.IsNullOrEmpty(agileConfiguration.JOBLIST_URL))
                {
                    LogManagement.LogException(Convert.ToInt32(args[0].Trim()), "Login URL or JobList URL is empty", "FieldglassForm");
                    CloseApplication();
                }

                if (string.IsNullOrEmpty(agileConfiguration.AUT_VIEWSTATE))
                    agileConfiguration.AUT_VIEWSTATE = "0";

                agileConfiguration.JOB_NEW_URL = "https://www.fieldglass.net/workflow_manager.do?moduleId=40&activityId=1360&sgjy=";

                InitializeComponent();

                // create a WebBrowser control
                browser = new WebBrowser();
                this.Controls.Add(browser);
                browser.Dock = System.Windows.Forms.DockStyle.Fill;
                browser.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(webBrowser1_DocumentCompleted);
                browser.ScriptErrorsSuppressed = true;

                rowIterationTimer = new Timer();
                rowIterationTimer.Tick += new EventHandler(rowIterationTimer_Tick);
                rowIterationTimer.Interval = 1000 * Convert.ToInt32(ConfigurationManager.AppSettings["SecondsRowIteration"].ToString().Trim());

                exitTimer = new Timer();
                exitTimer.Tick += new EventHandler(restartTimer_Tick);
                exitTimer.Interval = 60000 * Convert.ToInt32(ConfigurationManager.AppSettings["ExitTimeMins"].ToString().Trim());
                exitTimer.Start();
            }
            catch (Exception ex)
            {
                LogManagement.LogException(0, ex.ToString(), "FieldglassForm");
                CloseApplication();
            }
        }

        void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {
                browser = sender as WebBrowser;
                if (!browser.IsBusy && (browser.Url.ToString() == agileConfiguration.URL.Trim() || browser.Url.ToString().ToLower().Equals("https://www.fieldglass.net/login.do")))//"https://www.fieldglass.net/" Ind Amz change
                {
                    #region Login Failure
                    if (isLogin)
                    {
                        if (browser != null && browser.Document != null)
                        {
                            HtmlElement eleError = browser.Document.GetElementById("helpWelcome_new");
                            if (eleError != null && !string.IsNullOrEmpty(eleError.InnerText) && eleError.InnerText.ToLower().Contains("password has expired"))
                            {
                                LoginFailure(eleError.InnerText);
                            }
                            else
                            {
                                HtmlElementCollection elecollDiv = browser.Document.GetElementsByTagName("div");
                                foreach (HtmlElement eleD in elecollDiv)
                                {
                                    if (!string.IsNullOrEmpty(eleD.GetAttribute("classname")) && eleD.GetAttribute("classname").ToLower().Trim().Equals("globalerror")
                                        && !string.IsNullOrEmpty(eleD.InnerText) && eleD.InnerText.Length > 10 &&
                                        (eleD.InnerText.ToLower().Contains("login failed") || eleD.InnerText.ToLower().Contains("username or password was incorrect")))
                                    {
                                        if (Convert.ToInt32(ConfigurationManager.AppSettings["LoginCount"]) <= Convert.ToInt32(agileConfiguration.AUT_VIEWSTATE))
                                        {
                                            LoginFailure(eleD.InnerText);
                                        }
                                        else
                                        {
                                            agileConfiguration.AUT_VIEWSTATE = Convert.ToString(Convert.ToInt32(agileConfiguration.AUT_VIEWSTATE) + 1);
                                            JobDataLayer.UpdateLoginCount(agileConfiguration.AUT_VIEWSTATE, agileConfiguration.VMSClientID);
                                            CloseApplication();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    #endregion

                    #region Login
                    if (browser.Document.GetElementById("usernameId_new") != null && browser.Document.GetElementById("passwordId_new") != null
                        && !string.IsNullOrEmpty(agileConfiguration.Username) && !string.IsNullOrEmpty(agileConfiguration.Password))
                    {
                        HtmlElement eleLogin = browser.Document.GetElementById("usernameId_new");
                        if (eleLogin != null)
                        {
                            eleLogin.Focus();
                            eleLogin.SetAttribute("value", agileConfiguration.Username.Trim());
                            eleLogin.RemoveFocus();
                        }
                        eleLogin = browser.Document.GetElementById("passwordId_new");
                        if (eleLogin != null)
                        {
                            eleLogin.Focus();
                            eleLogin.SetAttribute("value", agileConfiguration.Password.Trim());
                            eleLogin.RemoveFocus();
                        }

                        HtmlElementCollection elecollButton = browser.Document.GetElementsByTagName("button");
                        foreach (HtmlElement ele in elecollButton)
                        {
                            if (!string.IsNullOrEmpty(ele.GetAttribute("value")) && ele.GetAttribute("value").ToLower().Trim().Equals("sign in"))
                            {
                                ele.Focus();
                                ele.InvokeMember("click");
                                isLogin = true;
                                LogManagement.LogTrace(0, "login clicked. ", "true");
                                break;
                            }
                        }
                    }
                    #endregion Login
                }

                if (isLogin)
                {
                    #region JobList Response Navigation
                    if (browser.Document.GetElementById("usernameId_new") == null)
                    {
                        agileConfiguration.JOB_NEW_URL = "https://www.fieldglass.net/workflow_manager.do?moduleId=40&activityId=1360&cf=1";
                        agileConfiguration.JOBLIST_URL = "https://www.fieldglass.net/job_posting_list.do?cf=1";
                        agileConfiguration.JOB_PAST_URL = "https://www.fieldglass.net/past_job_posting_list.do?moduleId=40&cf=1";

                        //add workmanager link
                        VMSFieldglass.jobURLList.Add(agileConfiguration.JOB_NEW_URL);

                        //add jobposting current link
                        VMSFieldglass.jobURLList.Add(agileConfiguration.JOBLIST_URL);

                        //add jobposting past link
                        if (Convert.ToInt32(ConfigurationManager.AppSettings["OrgId"].ToString()) == 50)
                            VMSFieldglass.jobURLList.Add(agileConfiguration.JOBLIST_URL);
                        else
                            VMSFieldglass.jobURLList.Add(agileConfiguration.JOB_PAST_URL);

                        if (VMSFieldglass.jobURLList.Count > 0)
                            browser.Navigate(VMSFieldglass.jobURLList[0].Trim());

                        isLogin = false;
                        rowIterationTimer.Start();

                        if (Convert.ToInt32(agileConfiguration.AUT_VIEWSTATE) != 0)
                        {
                            JobDataLayer.UpdateLoginCount("0", agileConfiguration.VMSClientID);
                        }
                        #region Old code
                        //HtmlElement eleForm = browser.Document.GetElementById("left");
                        //if (eleForm != null
                        //    && eleForm.CanHaveChildren
                        //    && eleForm.Children[0] != null
                        //    && eleForm.Children[0].TagName.ToLower().Trim() == "a"
                        //    && !string.IsNullOrEmpty(eleForm.Children[0].GetAttribute("href"))
                        //    && eleForm.Children[0].GetAttribute("href").ToLower().Trim().Contains("sgjy=")
                        //    )
                        //{
                        //    strhref = eleForm.Children[0].GetAttribute("href").Replace("sgjy=", "*");
                        //    int intIndex = strhref.IndexOf("*");
                        //    int intLength = strhref.Length - 1 - intIndex;
                        //    if (intIndex > 0)
                        //        strhref = strhref.Substring(intIndex + 1, intLength);

                        //    agileConfiguration.JOB_NEW_URL = "https://www.fieldglass.net/workflow_manager.do?moduleId=40&activityId=1360&sgjy=";
                        //    agileConfiguration.JOB_PAST_URL = "https://www.fieldglass.net/past_job_posting_list.do?moduleId=40&sgjy=";

                        //    //add workmanager link
                        //    VMSFieldglass.jobURLList.Add(agileConfiguration.JOB_NEW_URL + strhref);

                        //    //add jobposting current link
                        //    VMSFieldglass.jobURLList.Add(agileConfiguration.JOBLIST_URL + strhref);

                        //    //add jobposting past link
                        //    if (Convert.ToInt32(ConfigurationManager.AppSettings["OrgId"].ToString()) == 50)
                        //        VMSFieldglass.jobURLList.Add(agileConfiguration.JOBLIST_URL + strhref);
                        //    else
                        //        VMSFieldglass.jobURLList.Add(agileConfiguration.JOB_PAST_URL + strhref);

                        //    if (VMSFieldglass.jobURLList.Count > 0)
                        //        browser.Navigate(VMSFieldglass.jobURLList[0].Trim());

                        //    isLogin = false;
                        //    rowIterationTimer.Start();
                        //}
                        #endregion
                    }
                    #endregion JobList Response Navigation
                }
            }
            catch (Exception ex)
            {
                LogManagement.LogException(1, ex.ToString(), "webBrowser1_DocumentCompleted" + ", VmsId:" + agileConfiguration.VMSClientID);
                CloseApplication();
            }

        }
        void rowIterationTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (browser != null && browser.Document != null)// && browser.ReadyState == WebBrowserReadyState.Complete)
                {
                    #region JobList JobPosting Navigation
                    if ((browser.Document.GetElementById("splitWindowList") != null && VMSFieldglass.jobURLList.Count == 3)
                        || (browser.Document.GetElementById("contenttablejob_posting_supplier_list") != null && VMSFieldglass.jobURLList.Count == 2)
                        || (browser.Document.GetElementById("contenttablepast_job_posting_supplier_list") != null && VMSFieldglass.jobURLList.Count == 1))
                    {
                        if (!string.IsNullOrEmpty(browser.Document.Body.InnerHtml) && VMSFieldglass.jobList.Count == 0)
                        {
                            if (VMSFieldglass.jobURLList.Count == 3)
                            {
                                HtmlElement eleForm = browser.Document.GetElementById("cSelForm");
                                if (eleForm != null && !string.IsNullOrEmpty(eleForm.InnerHtml))
                                {
                                    VMSFieldglass.SetJobList(eleForm.InnerHtml, agileConfiguration.VMSClientID);
                                }
                            }
                            else if (VMSFieldglass.jobURLList.Count == 2 || VMSFieldglass.jobURLList.Count == 1)
                            {
                                GetJobListData();
                            }
                        }
                        if (VMSFieldglass.jobList.Count == 0)
                        {
                            if (VMSFieldglass.jobURLList.Count > 1 && !isJobListNavigated)
                            {
                                VMSFieldglass.jobURLList.RemoveAt(0);

                                browser.Navigate(VMSFieldglass.jobURLList[0].Trim());

                                isJobListNavigated = true;
                                isPostingJobs = false;
                                jobIDList = null;
                                VMSFieldglass.jobList.Clear();
                                VMSFieldglass.listPostingJobs.Clear();
                                intDDLCount = intTotalJobsCount = intPageCount = counter = 0;
                                VMSFieldglass.current = 1;
                                isExpandClick = false;

                                LogManagement.LogTrace(0, "Url Navigation", "Url number:" + VMSFieldglass.jobURLList.Count);

                            }
                            else if (VMSFieldglass.jobURLList.Count == 1 && intPageCount < counter && isPostingJobs)
                            {
                                CloseApplication();
                            }
                        }
                    }
                    #endregion JobList JobPosting Navigation

                    #region JobList Job Click
                    if (VMSFieldglass.jobList.Count > 0 && VMSFieldglass.jobList.Count >= VMSFieldglass.current && !isJobClicked)
                    {
                        browser.Navigate(VMSFieldglass.jobList[VMSFieldglass.current].JOB_EVENTTARGET);
                        isJobClicked = true;
                    }
                    #endregion JobList Job Click

                    #region JobList Job Create
                    else if (browser.Document.GetElementById("document") != null && isJobClicked)
                    {
                        HtmlElementCollection elecollCommon = browser.Document.GetElementsByTagName("li");
                        foreach (HtmlElement eleN in elecollCommon)
                        {
                            if (eleN != null && !string.IsNullOrEmpty(eleN.GetAttribute("classname")) && eleN.GetAttribute("classname").ToLower().Trim().Equals("documentstyle")
                                && !string.IsNullOrEmpty(eleN.InnerText) && VMSFieldglass.jobList.Count > 0)
                            {
                                if (VMSFieldglass.jobList.Count >= VMSFieldglass.current)
                                {
                                    if (!string.IsNullOrEmpty(browser.DocumentText) && eleN.InnerText.ToLower().Trim().Equals(VMSFieldglass.jobList[VMSFieldglass.current].JobCode.Trim().ToLower()))
                                    {
                                        VMSFieldglass.CreateJob(browser.DocumentText);
                                        isJobClicked = false;

                                        break;
                                    }
                                }
                            }
                        }

                        if (VMSFieldglass.current > VMSFieldglass.jobList.Count)
                        {
                            if (VMSFieldglass.jobURLList.Count > 1)
                            {
                                VMSFieldglass.jobURLList.RemoveAt(0);
                                VMSFieldglass.jobList.Clear();
                                VMSFieldglass.current = 1;

                                browser.Navigate(VMSFieldglass.jobURLList[0].Trim());

                                isJobListNavigated = true;
                                isPostingJobs = false;
                                jobIDList = null;
                                VMSFieldglass.jobList.Clear();
                                VMSFieldglass.listPostingJobs.Clear();
                                intDDLCount = intTotalJobsCount = intPageCount = counter = 0;
                                VMSFieldglass.current = 1;
                                isExpandClick = false;

                                LogManagement.LogTrace(0, "Url Navigation(CreateJob)", "Url number:" + VMSFieldglass.jobURLList.Count);
                            }
                            else
                            {
                                CloseApplication();
                            }
                        }
                    }
                    #endregion JobList Job Create
                }

            }
            catch (Exception ex)
            {
                LogManagement.LogException(0, ex.ToString(), "RowIteration()");
            }
        }

        void GetJobListData()
        {
            HtmlElement eleTotalJobs = browser.Document.GetElementById("dropdownlistContentgridpagerlistjob_posting_supplier_list");
            if (eleTotalJobs == null)
                eleTotalJobs = browser.Document.GetElementById("dropdownlistContentgridpagerlistpast_job_posting_supplier_list");
            if (eleTotalJobs != null && !string.IsNullOrEmpty(eleTotalJobs.InnerText) && intTotalJobsCount <= 0)
            {
                #region JobCount & PageCount
                intDDLCount = Convert.ToInt32(eleTotalJobs.InnerText.Trim());
                HtmlElementCollection elecollTotal = browser.Document.GetElementsByTagName("span");
                foreach (HtmlElement item in elecollTotal)
                {
                    if (!string.IsNullOrEmpty(item.GetAttribute("classname")) && (item.GetAttribute("classname").ToLower().Trim().Equals("fr itemsfound") || item.GetAttribute("classname").ToLower().Trim().Equals("fr itemsfound groupbymargin")) && !string.IsNullOrEmpty(item.InnerText) && item.InnerText.ToLower().Contains("items found"))
                    {
                        int intT = 0;
                        string[] arrStrTotal = item.InnerText.Trim().Split(' ');
                        foreach (var str in arrStrTotal.Reverse())
                        {
                            if (int.TryParse(str.Trim(), out intT))
                            {
                                intTotalJobsCount = intT;
                                intPageCount = intTotalJobsCount / intDDLCount;

                                break;
                            }
                        }
                        break;
                    }
                }
                #endregion
            }
            if (!isExpandClick && intPageCount >= counter)
            {
                HtmlElementCollection elecollNext = browser.Document.GetElementsByTagName("a");
                foreach (HtmlElement item in elecollNext)
                {
                    if (!string.IsNullOrEmpty(item.InnerText) && item.InnerText.ToLower().Trim().Equals("expand all"))
                    {
                        item.Focus();
                        item.InvokeMember("click");
                        isExpandClick = true;
                        break;
                    }
                }
            }
            else if (isExpandClick && intPageCount >= counter)
            {
                #region Expand job list
                HtmlElement eleForm = browser.Document.GetElementById("cSelForm");
                if (eleForm != null && !string.IsNullOrEmpty(eleForm.InnerHtml))
                {
                    List<JobMetaData> tempListJobs = FieldglassHelper.GetJobList(eleForm.InnerHtml);
                    foreach (var item in tempListJobs)
                    {
                        if (VMSFieldglass.listPostingJobs.Where(x => x.JobCode.Contains(item.JobCode)).FirstOrDefault() == null)
                            VMSFieldglass.listPostingJobs.Add(item);
                    }

                    HtmlElementCollection elecollNext = browser.Document.GetElementsByTagName("div");
                    foreach (HtmlElement item in elecollNext)
                    {
                        if (!string.IsNullOrEmpty(item.GetAttribute("title")) && item.GetAttribute("title").ToLower().Trim().Equals("next"))
                        {
                            item.Focus();
                            item.InvokeMember("click");

                            counter++;
                            isExpandClick = false;
                            break;
                        }
                    }
                }
                #endregion
            }
            else if (VMSFieldglass.jobList.Count == 0 && VMSFieldglass.listPostingJobs.Count > 0 && intPageCount < counter && !isPostingJobs)
            {
                var jobs = VMSFieldglass.listPostingJobs.Distinct().Select(X => X.JobCode).ToList();

                jobIDList = new JobIDList() { VMSClientID = agileConfiguration.VMSClientID, JobsIDList = jobs };

                var newJobs = jobCache.GetNewJobList(jobIDList, agileConfiguration.VMSClientID);

                #region Check job code with "Baxalta" client only
                if (agileConfiguration.VMSClientID == 83)
                {
                    StringBuilder sbJobCodes = new StringBuilder();
                    JobIDList newJobList = new JobIDList() { VMSClientID = agileConfiguration.VMSClientID, JobsIDList = new List<string>() };
                    foreach (string job in newJobs.JobsIDList)
                    {
                        if (!string.IsNullOrEmpty(job))
                            sbJobCodes.Append(job + ",");
                    }
                    if (sbJobCodes != null && sbJobCodes.Length > 0)
                    {
                        sbJobCodes.Replace(sbJobCodes.ToString(), sbJobCodes.ToString().TrimEnd(new char[] { ',' }));
                        newJobList.JobsIDList.AddRange(JobDataLayer.CheckDupJobCodeUsingCompanyId(sbJobCodes.ToString(), Convert.ToInt32(ConfigurationManager.AppSettings["BaxaltaCompanyId"].ToString()), 1).Split(new char[] { ',' }));//1283 config.CompanyId

                        foreach (var item in newJobList.JobsIDList)
                        {
                            if (!string.IsNullOrEmpty(item))
                                newJobs.JobsIDList.Remove(item);
                        }
                    }
                }
                #endregion

                var jobMetadataList = VMSFieldglass.listPostingJobs.FindAll(x => newJobs.JobsIDList.Distinct().Contains(x.JobCode));

                for (int count = 0; count < jobMetadataList.Count; count++)
                {
                    if (!VMSFieldglass.jobList.ContainsKey(count + 1))
                        VMSFieldglass.jobList.Add(count + 1, jobMetadataList[count]);
                }

                isPostingJobs = true;
                isJobListNavigated = false;
            }
            else if (VMSFieldglass.jobList.Count == 0 && VMSFieldglass.listPostingJobs.Count == 0 && intPageCount < counter)
            {
                isJobListNavigated = false;
                isPostingJobs = true;
            }
        }

        void LoginFailure(string strError)
        {
            try
            {
                if (!ConfigurationManager.AppSettings["SkipFailLoginNotificationVmsId"].Contains("(" + agileConfiguration.VMSClientID + ")"))
                {
                    LogManagement.LogException(1, "webBrowser1_DocumentCompleted()_LoginError, VmsId:" + agileConfiguration.VMSClientID + ", Error:" + strError, "");

                    VMSFieldglass.UpdateVmsFailure(agileConfiguration.VMSClientID);

                    string vmsName = ConfigurationManager.AppSettings["VmsName"].ToString().Trim();

                    string userMessage = "Vms :- " + vmsName + " ,  Client :- " + agileConfiguration.Clientname + " , User Name :- " + agileConfiguration.Username + "<br/><br/>Failure Message: " + strError;

                    VMSFieldglass.SaveLeoAlert(
                        userMessage,
                        Convert.ToInt32(ConfigurationManager.AppSettings["OrgId"].ToString()),
                        2,
                        true,
                        Convert.ToInt32(ConfigurationManager.AppSettings["CreatedById"].ToString()),
                        DateTime.Now);

                    VMSFieldglass.SaveEmailNotification(
                        Constants.OBJECT_CODE_ERROR,
                        Convert.ToInt32(ConfigurationManager.AppSettings["OrgId"].ToString()),
                        Constants.REGION,
                        VMSFieldglass.GetRecruitersEmailIdWithComa(agileConfiguration.VMSClientID),
                        ConfigurationManager.AppSettings["FromAddress"].ToString(),
                        ConfigurationManager.AppSettings["LoginErrorSubject"].ToString(),
                        ConfigurationManager.AppSettings["VmsActivityCredentialError"].ToString() + "<br/><br/>" + userMessage,
                        false,
                        string.Empty,
                        ConfigurationManager.AppSettings["FromName"].ToString(),
                        DateTime.Now,
                        string.Empty,
                        ConfigurationManager.AppSettings["BccEmail"].ToString(),
                        string.Empty,
                        string.Empty,
                        string.Empty,
                        agileConfiguration.VMSClientID,
                        0);
                    //VMSFieldglass.GetUserName(Convert.ToInt32(ConfigurationManager.AppSettings["CreatedById"].ToString()))
                }
            }
            catch (Exception ex)
            {
                LogManagement.LogException(0, ex.ToString(), "webBrowser1_DocumentCompleted()_LoginFailure()");
            }
            finally
            {
                CloseApplication();
            }
        }
        void restartTimer_Tick(object sender, EventArgs e)
        {
            if (agileConfiguration != null && agileConfiguration.VMSClientID > 0)
                LogManagement.LogTrace(agileConfiguration.VMSClientID, "restartTimer_Tick()", "0");
            Environment.Exit(1);
        }
        private void FieldglassForm_Load(object sender, EventArgs e)
        {
            browser.Navigate(agileConfiguration.URL);

        }
        private void CloseApplication()
        {
            try
            {
                if (agileConfiguration != null)
                    LogManagement.LogTrace(0, "CloseApp()", "VmsId: " + agileConfiguration.VMSClientID);
                if (browser != null && browser.Document != null && !browser.IsBusy)
                {
                    HtmlElementCollection elecollA = browser.Document.GetElementsByTagName("a");
                    foreach (HtmlElement item in elecollA)
                    {
                        if (!string.IsNullOrEmpty(item.GetAttribute("classname")) && item.GetAttribute("classname").ToLower().Trim().Equals("signout"))
                        {
                            item.Focus();
                            item.InvokeMember("click");
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogManagement.LogException(0, ex.ToString(), "CloseApp()");
            }
            finally
            {
                Environment.Exit(1);
            }

        }
    }
}
